﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Invoice.Repository;
using Invoice.Model;
using System.Web.Mvc;

namespace Invoice.Business
{
    public class InvoiceManager : IInvoiceManager
    {

        private IRepository<Customer> CustomerRepository;
        private IRepository<InvoiceStatu> StatusRepository;
        private IRepository<InvoiceParent> ParentRepository;
        private IRepository<InvoiceChild> ChildRepository;
        private IRepository<InvoiceProcedure_Result> InvoiceDetailsRepository;


        public InvoiceManager()
        {
            CustomerRepository = new Repository<Customer>();
            StatusRepository = new Repository<InvoiceStatu>();
            ParentRepository = new Repository<InvoiceParent>();
            ChildRepository = new Repository<InvoiceChild>();
            InvoiceDetailsRepository = new Repository<InvoiceProcedure_Result>();
        }

        public IQueryable<SelectListItem> GetCustomerDropDownList()
        {
            try
            {
                return CustomerRepository.Get().OrderBy(Order => Order.CustomerName).
                   Select(Lst => new SelectListItem { Value = Lst.CustomerID.ToString(), Text = Lst.CustomerName });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IQueryable<SelectListItem> GetStatusDropDownList()
        {
            try
            {
                return StatusRepository.Get().OrderBy(Order => Order.StatusName).
                   Select(Lst => new SelectListItem { Value = Lst.StatusID.ToString(), Text = Lst.StatusName });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<SelectListItem> GetDropDownList(List<SelectListItem> ListItem)
        {
            ListItem.Insert(0, new SelectListItem() { Text = "Select", Value = "0" });
            return ListItem;
        }

        public virtual int SaveProject(string Billto, string invoiceno, string invoicedate, string invoiceduedate, string StatusID, string Invoicenote)
        {
            try
            {
                InvoiceParent Parent = new InvoiceParent();
                Parent.CustomerID = Convert.ToInt32(Billto);
                Parent.Invoiceno = invoiceno;
                Parent.Invoicedate = Convert.ToDateTime(invoicedate);
                Parent.InvoiceDuedate = Convert.ToDateTime(invoiceduedate);
                Parent.StatusID = Convert.ToInt32(StatusID);
                Parent.Invoicenote = Invoicenote;
                ParentRepository.Insert(Parent);
                return ParentRepository.Get(x => x.InvoiceParentID != 0).Select(x => x.InvoiceParentID).OrderByDescending(x => x).FirstOrDefault();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void SaveInvoiceItem(InvoiceChild invoiceChildItem)
        {
            try
            {
                ChildRepository.Insert(invoiceChildItem);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<InvoiceProcedure_Result> GetInvoiceDetails()
        {
            try
            {
                return InvoiceDetailsRepository.Get().ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}

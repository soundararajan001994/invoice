﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication5.Models
{
    public class Employee
    {
        public int id { get; set; }
        public string employeeName { get; set; }
        public string joinDate { get; set; }
        public string selectedDepartment { get; set; }
        public int selectedDepartmentID { get; set; }
        public string jobDescription { get; set; }
        public bool IsChanged { get; set; }
    }
}

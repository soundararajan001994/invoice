﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication5.Models;

namespace WebApplication5.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        //private readonly BookContext _dbContext;
        //public BooksController(BookContext dbContext)
        //{
        //    this._dbContext = dbContext;
        //}
        public IActionResult Get()
        {
            var employees = new List<Employee>() {
            new Employee(){id= 0,
                        employeeName= "Jane",
                        joinDate= "11-11-1111",
                        selectedDepartment= "IT",
                        selectedDepartmentID= 1,
                        jobDescription= "Nerd",IsChanged=false},
            new Employee(){id= 1,
                        employeeName= "Peter",
                        joinDate= "12-12-1212",
                        selectedDepartment= "Accounting",
                        selectedDepartmentID= 2,
                        jobDescription= "Moneier",IsChanged=false}
            };
            //var books = _dbContext.Books.ToList();
            return Ok(employees);
        }
        [Route("GetOEM")]
        [HttpPost]
        public IActionResult GetOEM()
        {
            var OEM = new List<OEM>() {
            new OEM(){id= 1,
                        name= "Renault"},
            new OEM(){id= 2,
                        name= "PSA"},
            new OEM(){id= 3,
                        name= "Renault123"}
            };
            return Ok(OEM);
        }


        [Route("GetDataType")]
        [HttpPost]
        public IActionResult GetDataType(int? OEMid)
        {

            var DataType = new List<DataType>() {
            new DataType(){id= 1,ManufacturerId=1,
                        name= "Labour"},
            new DataType(){id= 2,ManufacturerId=1,
                        name= "Parts"},
            new DataType(){id= 3,ManufacturerId=1,
                        name= "Forfait"},
            new DataType(){id= 4,ManufacturerId=2,
                        name= "Labour"},
            new DataType(){id= 5,ManufacturerId=2,
                        name= "Parts"},
            };
            var dataType = DataType.Where(r => r.ManufacturerId== OEMid).ToList();
            return Ok(dataType);
        }


        [Route("GetColumnNames")]
        [HttpPost]
        public IActionResult GetColumnNames(int? DataTypeid)
        {

            var DataType = new List<ColumnName>() {
             new ColumnName(){id=1,DataTypeId=1, name= "Famille et segment"},
 new ColumnName(){id=2,DataTypeId=1, name= "Français"},
 new ColumnName(){id=3,DataTypeId=1, name= "English"},
 new ColumnName(){id=4,DataTypeId=1, name= "Part Category"},
 new ColumnName(){id=5,DataTypeId=1, name= "PartCategoryFallback"},
 new ColumnName(){id=6,DataTypeId=1, name= "Component Condition"},
 new ColumnName(){id=7,DataTypeId=1, name= "JobCategory1"},
 new ColumnName(){id=8,DataTypeId=1, name= "JobCategory2"},
 new ColumnName(){id=9,DataTypeId=1, name= "JobCategory3"},
 new ColumnName(){id=10,DataTypeId=1, name= "JobCategory4"},
 new ColumnName(){id=11,DataTypeId=1, name= "JobCategory5"},
 new ColumnName(){id=12,DataTypeId=1, name= "JobCategory6"},
 new ColumnName(){id=13,DataTypeId=1, name= "JobCategory7"},
 new ColumnName(){id=14,DataTypeId=1, name= "JobCategory8"},
 new ColumnName(){id=15,DataTypeId=1, name= "Notes"},
 new ColumnName(){id=16,DataTypeId=2, name= "Operation Code"},
 new ColumnName(){id=17,DataTypeId=2, name= "OperationDesc"},
 new ColumnName(){id=18,DataTypeId=2, name= "JobCategoryRef"},
 new ColumnName(){id=19,DataTypeId=2, name= "AthorisMode"},
 new ColumnName(){id=20,DataTypeId=2, name= "AthorisPosition"},
 new ColumnName(){id=21,DataTypeId=3, name= "ForfaitCode"},
 new ColumnName(){id=22,DataTypeId=3, name= "Mapping description"},
 new ColumnName(){id=23,DataTypeId=3, name= "Forfait description"},
 new ColumnName(){id=24,DataTypeId=3, name= "JobCategoryRef"},
 new ColumnName(){id=25,DataTypeId=3, name= "Mode"},
 new ColumnName(){id=26,DataTypeId=3, name= "Position"},
 new ColumnName(){id=27,DataTypeId=3, name= "OilGrade"},
 new ColumnName(){id=28,DataTypeId=3, name= "CompCond"},
 new ColumnName(){id=29,DataTypeId=3, name= "Notes"},
 new ColumnName(){id=30,DataTypeId=4, name= "DesignationCode"},
 new ColumnName(){id=31,DataTypeId=4, name= "PSACategoryCount"},
 new ColumnName(){id=32,DataTypeId=4, name= "PSACategory"},
 new ColumnName(){id=33,DataTypeId=4, name= "PartDescription"},
 new ColumnName(){id=34,DataTypeId=4, name= "PSACategoryDescription"},
 new ColumnName(){id=35,DataTypeId=4, name= "PSAParentCategoryDescription"},
 new ColumnName(){id=36,DataTypeId=4, name= "PartCategoryRef"},
 new ColumnName(){id=37,DataTypeId=4, name= "ComponentCondition"},
 new ColumnName(){id=38,DataTypeId=4, name= "JobCategory1"},
 new ColumnName(){id=39,DataTypeId=4, name= "JobCategory2"},
 new ColumnName(){id=40,DataTypeId=4, name= "JobCategory3"},
 new ColumnName(){id=41,DataTypeId=4, name= "JobCategory4"},
 new ColumnName(){id=42,DataTypeId=4, name= "JobCategory5"},
 new ColumnName(){id=43,DataTypeId=4, name= "JobCategory6"},
 new ColumnName(){id=44,DataTypeId=4, name= "JobCategory7"},
 new ColumnName(){id=45,DataTypeId=4, name= "JobCategory8"},
 new ColumnName(){id=46,DataTypeId=4, name= "Notes"},
 new ColumnName(){id=47,DataTypeId=5, name= "ElementCode"},
 new ColumnName(){id=48,DataTypeId=5, name= "NatureCode"},
 new ColumnName(){id=49,DataTypeId=5, name= "ContextCode"},
 new ColumnName(){id=50,DataTypeId=5, name= "Combined"},
 new ColumnName(){id=51,DataTypeId=5, name= "Element"},
 new ColumnName(){id=52,DataTypeId=5, name= "Nature"},
 new ColumnName(){id=53,DataTypeId=5, name= "Context"},
 new ColumnName(){id=54,DataTypeId=5, name= "JobCategoryRef"},
 new ColumnName(){id=55,DataTypeId=5, name= "AthorisMode"},
 new ColumnName(){id=56,DataTypeId=5, name= "AthorisPosition"},
 new ColumnName(){id=57,DataTypeId=5, name= "Notes"}
            };
            var columnname = DataType.Where(r => r.DataTypeId == DataTypeid).ToList();
            return Ok(columnname);
        }

        //[Route("Create")]
        //[HttpPost]
        //public IActionResult Create(Book model)
        //{
        //    var result = _dbContext.Books.Add(model);
        //    _dbContext.SaveChanges();
        //    var books = _dbContext.Books.ToList();
        //    return Ok(books);
        //}
        //[Route("Update")]
        //[HttpPost]
        //public IActionResult Update(Book model)
        //{

        //    var book = _dbContext.Books.Where(x=>x.ID==model.ID).FirstOrDefault();
        //    book.Name = model.Name;
        //    book.Title = model.Title;
        //    _dbContext.SaveChanges();
        //    var books = _dbContext.Books.ToList();
        //    return Ok(books);
        //}
        //[Route("Delete")]
        //[HttpPost]
        //public IActionResult Delete(int? id)
        //{

        //    var book = _dbContext.Books.Where(x => x.ID == id).FirstOrDefault();
        //    _dbContext.Books.Remove(book);
        //    _dbContext.SaveChanges();
        //    var books = _dbContext.Books.ToList();
        //    return Ok(books);
        //}
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq.Expressions;
using Invoice.Model;

namespace Invoice.Repository
{
    public interface IRepository<TEntity>
    {
        IQueryable<TEntity> Get(Expression<Func<TEntity, bool>> filter = null, string includeProperties = "");
        TEntity GetByID(object id);
        void Update(TEntity entity);
        void Delete(object id);
        void Insert(TEntity entity);
    }
}

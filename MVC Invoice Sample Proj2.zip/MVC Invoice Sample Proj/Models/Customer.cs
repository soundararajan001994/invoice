﻿using Invoice.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_Invoice_Sample_Proj.Models
{
    public class CustomerModel
    {
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public int StatusID { get; set; }
        public string StatusName { get; set; }
        public IEnumerable<SelectListItem> CustomerList { get; set; }

        public IEnumerable<SelectListItem> StatusList { get; set; }
        public List<InvoiceProcedure_Result> InvoiceResult { get; set; }
    }
}
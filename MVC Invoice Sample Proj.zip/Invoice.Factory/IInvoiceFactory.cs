﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Invoice.Model;
using Invoice.Business;

namespace Invoice.Factory
{
    public interface IInvoiceFactory
    {
        IInvoiceManager InvoiceManager();
    }
}

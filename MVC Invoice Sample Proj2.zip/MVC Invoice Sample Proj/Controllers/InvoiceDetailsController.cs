﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Invoice.Model;
using Invoice.Factory;
using MVC_Invoice_Sample_Proj.Models;

namespace MVC_Invoice_Sample_Proj.Controllers
{
    public class InvoiceDetailsController : Controller
    {
        private IInvoiceFactory InvoiceFactorys;

        public InvoiceDetailsController()
        {
            InvoiceFactorys = new InvoiceFactory();
        }
        // GET: InvoiceDetails
        public ActionResult Index()
        {
            
            return View();
        }

        public ActionResult Create()
        {

            CustomerModel model = new CustomerModel();
            model.CustomerList = new SelectList(InvoiceFactorys.InvoiceManager().GetDropDownList(InvoiceFactorys.InvoiceManager().GetCustomerDropDownList().ToList()), "Value", "Text", 0);
            model.StatusList = new SelectList(InvoiceFactorys.InvoiceManager().GetDropDownList(InvoiceFactorys.InvoiceManager().GetStatusDropDownList().ToList()), "Value", "Text", 0);
            return View(model);
        }


        [HttpPost]
        public ActionResult Create(FormCollection projectData, int projectId = 0)
        {
            int LastProjectID = InvoiceFactorys.InvoiceManager().SaveProject(Convert.ToString(projectData["HidBillto"]),
                Convert.ToString(projectData["Invoiceno"]),
                Convert.ToString(projectData["InvoiceDate"]),
                Convert.ToString(projectData["InvoiceDueDate"]),
                Convert.ToString(projectData["HidStatus"]),
                Convert.ToString(projectData["txtinvoicenotes"])
                );

            if (Array.FindAll(projectData.AllKeys, item => item.Contains("TRC")).Length > 0)
            {
                int RowsCount = Convert.ToInt32(projectData["HidTableRowsCountParent"]);
                for (int i = 1; i <= RowsCount; i++)
                {
                    if (Array.FindAll(projectData.AllKeys, item => item.Contains("TRC" + i)).Length > 0)
                    {
                        //  int LastSupportItemId;
                        //Get support item details and save into ProjectSupportItem table and get last SupportItem id.
                        InvoiceChild InvoiceChildItem = new InvoiceChild();
                        InvoiceChildItem.InvoiceParentID = LastProjectID;

                        if (!string.IsNullOrEmpty(projectData["TRC" + i + "_ddlProduct"]) && projectData["TRC" + i + "_ddlProduct"] != "0")
                            InvoiceChildItem.ProductID = Convert.ToInt32(projectData["TRC" + i + "_ddlProduct"]);

                        if (!string.IsNullOrEmpty(projectData["TRC" + i + "_txtDesc"]) && projectData["TRC" + i + "_txtDesc"] != "0")
                            InvoiceChildItem.ProductNote = Convert.ToString(projectData["TRC" + i + "_txtDesc"]);

                        if (projectData["TRC" + i + "_txtPrice"] != "" && projectData["TRC" + i + "_txtPrice"] != null)
                            InvoiceChildItem.Price = Convert.ToDecimal(projectData["TRC" + i + "_txtPrice"]);

                        if (projectData["TRC" + i + "_txtQty"] != "" && projectData["TRC" + i + "_txtQty"] != null)
                            InvoiceChildItem.Qty = Convert.ToDecimal(projectData["TRC" + i + "_txtQty"]);

                        if (projectData["TRC" + i + "_txttax"] != "" && projectData["TRC" + i + "_txttax"] != null)
                            InvoiceChildItem.Tax = Convert.ToDecimal(projectData["TRC" + i + "_txttax"]);

                        if (projectData["TRC" + i + "_lbltotal"] != "" && projectData["TRC" + i + "_lbltotal"] != null)
                            InvoiceChildItem.Total = Convert.ToDecimal(projectData["TRC" + i + "_lbltotal"]);

                        InvoiceFactorys.InvoiceManager().SaveInvoiceItem(InvoiceChildItem);
                    }
                }
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult GetBrand(int projectId)
        {
            try
            {
               
                return Json("");
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
﻿Service = {
    // All Ajax function call
    getData: function (url, dataType, parameters, async, type) {
        var GridData = '';
        $.ajax({
            //url: url, dataType: dataType, type: type, data: JSON.stringify(parameters), async: async, success: function (data) {
            //    GridData = data;
            //},
            url: url, dataType: dataType, type: type, data: parameters, async: async, cache: false, success: function (data) {
                GridData = data;
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert('Error occured');
            }
        });
        return GridData;
    },
    CheckData: function (url, dataType, parameters, async) {
        var result = '';
        $.ajax({
            url: url, dataType: dataType, type: 'GET', data: parameters, async: async, cache: false, success: function (data) {
                result = data;
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert('Error occured');
            }
        });
        return result;
    },
    CheckHTMLData: function (url, dataType, contentType, parameters, async) {
        var result = '';
        $.ajax({
            url: url, dataType: dataType, contentType: contentType, type: 'GET', data: parameters, async: async, cache: false, success: function (data) {
                result = data;
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert('Error occured');
            }
        });
        return result;
    }
}




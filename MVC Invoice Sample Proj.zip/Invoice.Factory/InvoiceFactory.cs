﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Invoice.Business;

namespace Invoice.Factory
{
    public class InvoiceFactory :IInvoiceFactory
    {
        public IInvoiceManager InvoiceManager()
        {
            return new InvoiceManager();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Invoice.Model;

namespace Invoice.Business
{
    public interface IInvoiceManager
    {
        IQueryable<SelectListItem> GetCustomerDropDownList();
        IQueryable<SelectListItem> GetStatusDropDownList();
        List<SelectListItem> GetDropDownList(List<SelectListItem> ListItem);
        int SaveProject(string Billto, string invoiceno, string invoicedate, string invoiceduedate, string StatusID, string Invoicenote);
        void SaveInvoiceItem(InvoiceChild invoiceChildItem);
        List<InvoiceProcedure_Result> GetInvoiceDetails();
    }
}

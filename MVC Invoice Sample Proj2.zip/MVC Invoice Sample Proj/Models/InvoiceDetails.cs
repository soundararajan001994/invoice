﻿using Invoice.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace MVC_Invoice_Sample_Proj.Models
{
    public class InvoiceDetails
    {
   
    }
}
﻿//Child support item of POSM
AddInvoiceParent = function () {
var rowsCount = 1;
var table = document.getElementById("TblInvoiceDetails");
    var rows = table.getElementsByTagName("tbody");
    if (rows.tbodyInvoiceDetails.rows.length != 0) {
        rowsCount = rows.tbodyInvoiceDetails.rows.length + 1;
    } else {
        rowsCount = 1;
    }
     $('#HidTableRowsCountParent').val(rowsCount);
 $('#tbodyInvoiceDetails').append("<tr id=TRItemChild_" + rowsCount + "> <input type='hidden' class='QuantityEnable' name=TRC" + rowsCount + "_HidSupportItemID id=TRC" + rowsCount + "_HidSupportItemID /> <input type='hidden' class='QuantityEnable' name=TRC" + rowsCount + "_HidIsDeleted id=TRC" + rowsCount + "_HidIsDeleted /> <input type='hidden' class='QuantityEnable' name=TRC" + rowsCount + "_HidPrmSupportItemId id=TRC" + rowsCount + "_HidPrmSupportItemId /> <input type='hidden' class='QuantityEnable' name=TRC" + rowsCount + "_HidddlCategory id=TRC" + rowsCount + "_HidddlCategory /> <input type='hidden' class='QuantityEnable' name=TRC" + rowsCount + "_HidddlSupportItem id=TRC" + rowsCount + "_HidddlSupportItem />" +
                       
  "<td>"+rowsCount+"</td>" +
 "<td><div width='500px'><select class='form-control input-sm dropdownlist ddllist_on ddlProduct QuantityEnable' placeholder='Description' id=TRC" + rowsCount + "_ddlProduct name='TRC" + rowsCount + "_ddlProduct'></select></div></td > " +
"<td><input name=TRC" + rowsCount + "_txtDesc id=TRC" + rowsCount + "_txtDesc maxlength='300' placeholder='Description'  type='text' class='form-control' /></td>" +                     
   "<td><input name=TRC" + rowsCount + "_txtPrice id=TRC" + rowsCount + "_txtPrice placeholder='Price' onkeypress='return isNumberKey(event)' onblur=CalculateTotal('" + rowsCount + "'); onpaste='return false;' onDrop='return false;' type='text' class='form-control' /></td>" +
                        "<td><input name=TRC" + rowsCount + "_txtQty id=TRC" + rowsCount + "_txtQty maxlength='6' onkeypress='return isNumberKey(event)' onblur=CalculateTotal('" + rowsCount + "'); placeholder='Qty' onpaste='return false;' onDrop='return false;' type='text' class='form-control' /></td>" +
                        "<td><input name=TRC" + rowsCount + "_txttax id=TRC" + rowsCount + "_txttax maxlength='6' onkeypress='return isNumberKey(event)' onblur=CalculateTotal('" + rowsCount + "'); placeholder='tax %' onpaste='return false;' onDrop='return false;' type='text' class='form-control' /></td>" +
                        "<td><label id=TRC" + rowsCount + "_lbltotal></td>" +
                        "<td><div class='padding-xs paddingLR-md'><a class='cursor' onclick=DeleteInvoicedetails(" + rowsCount + ");><i class='fa fa-trash-o text-danger'>Delete</i></a></div></td></tr >");
              
 var ProductNames = [
                { Value: 1, Text: 'ApplePhone1'},
{ Value: 2, Text: 'SamsungGalaxy'},
{ Value: 3, Text: 'Oppo Pro'}];
    BindProduct('TRC' + rowsCount + '_ddlProduct', ProductNames);
    return false;
}


//This function is used to bind support item drop down
BindProduct = function (ItemId, Data) {
    $('#' + ItemId).empty();
    $('#' + ItemId).append('<option value="">Please Select</option>');
    for (var i = 0; i < Data.length; i++) {
        $('#' + ItemId).append($("<option></option>").val(Data[i].Value).html(Data[i].Text));
    }
}

DeleteInvoicedetails = function (RowId) {
  $('#TRItemChild_' + RowId).remove();
CalculateGrandTotal(RowId);
 return false;
}

function isNumberKey(evt)
       {
          var charCode = (evt.which) ? evt.which : evt.keyCode;
          if (charCode != 46 && charCode > 31 
            && (charCode < 48 || charCode > 57))
             return false;

          return true;
       }

CalculateTotal = function (Rowno) {
    var price= $('#TRC' + Rowno + '_txtPrice').val();
    var Qty= $('#TRC' + Rowno + '_txtQty').val();
    if (Qty != '' && price != '') {
            var Total=parseFloat(parseFloat(price * Qty)).toFixed(2);
            $('#TRC' + Rowno + '_lbltotal').text(Total);
    }
CalculateGrandTotal(Rowno);
}

CalculateGrandTotal = function (Rowno) {
    var SubTotal = 0;
var Taxtotal =0;
var Grandtotal = 0;
var rowsCount = 1;
var table = document.getElementById("TblInvoiceDetails");
    var rows = table.getElementsByTagName("tbody");
for (var i = 0; i < rows.tbodyInvoiceDetails.rows.length; i++) {
        var Sub=$('#TRC' +rowsCount + '_lbltotal').text();
        var Tax=$('#TRC' +rowsCount + '_txttax').val();
        SubTotal += parseFloat((parseFloat(Sub != '' ? (Sub) : 0)));
        Taxtotal += parseFloat((parseFloat(Tax != '' ? (Tax) : 0)));
        Grandtotal +=  parseFloat((parseFloat(Sub != '' ? (Sub) : 0) + parseFloat(Tax != '' ? (Tax) : 0)));
        rowsCount = rowsCount + 1;
    }

    if (SubTotal > 0) {
        $('#lblSubTotal').text(parseFloat(SubTotal).toFixed(2));
    }
if (Taxtotal > 0) {
        $('#lblTaxTotal').text(parseFloat(Taxtotal).toFixed(2));
    }
if (Grandtotal > 0) {
        $('#lblGrandTotal').text(parseFloat(Grandtotal).toFixed(2));
    }
}


Validate = function () {
var Customer = $('#ddlCustomer').val();
var Status = $('#ddlStatus').val();
var Invoiceno = $('#Invoiceno').val();
var InvoiceDate = $('#InvoiceDate').val();
var InvoiceDueDate = $('#InvoiceDueDate').val();
var Status = $('#ddlStatus').val();
 $('#HidBillto').val(Customer);
 $('#HidStatus').val(Status);
var message="";
if(Customer=='0' || Customer=="")
{
message+="Customer"+ '\n';
}
if(Invoiceno=='0' || Invoiceno=="")
{
message+="Invoice no" +'\n';
}
if(InvoiceDate=='0' || InvoiceDate=="")
{
message+="Invoice Date"+ '\n';
}
if(InvoiceDueDate=='0' || InvoiceDueDate=="")
{
message+="Invoice Due Date"+ '\n';
}
if(Status=='0' || Status=="")
{
message+="Status"+ '\n';
}

if(message!="")
{
var test="Below Fields cannot be Empty"+ '\n';
    alert(test+message);
return false;
}
}